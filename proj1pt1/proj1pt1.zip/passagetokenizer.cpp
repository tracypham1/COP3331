#include "passagetokenizer.h"

PassageToken::PassageToken(){
    name = " ";
    text = " ";
}